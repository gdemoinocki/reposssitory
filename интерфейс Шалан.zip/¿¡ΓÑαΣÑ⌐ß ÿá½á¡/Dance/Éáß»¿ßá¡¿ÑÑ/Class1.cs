using System;

namespace Расписаниее
{
    public class Class1
    {
    }
}
