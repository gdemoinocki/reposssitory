using System;

namespace Расписание
{
    public class Class1
    {
    }
}
