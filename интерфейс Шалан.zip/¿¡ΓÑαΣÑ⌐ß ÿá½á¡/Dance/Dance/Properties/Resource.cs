﻿namespace Dance.Properties
{
    internal class Resource
    {
        internal static object click;
    }
}