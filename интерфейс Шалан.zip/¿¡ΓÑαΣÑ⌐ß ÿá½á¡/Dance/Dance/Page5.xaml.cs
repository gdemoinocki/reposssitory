﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Dance
{
    /// <summary>
    /// Логика взаимодействия для Page5.xaml
    /// </summary>
    public partial class Page5 : Page
    {
        public Page5()
        {
            InitializeComponent();

        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            button.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#B7968D"));
            button.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#D8D5D2"));
            // Проверяем, что текст в TextBox начинается не с "+7"
            if (!myTextBox1.Text.StartsWith("+7"))
            {
                // Сохраняем текущую позицию курсора
                int caretIndex = myTextBox1.CaretIndex;

                // Добавляем "+7" в начало текста
                myTextBox1.Text = "+7" + myTextBox1.Text;

                // Восстанавливаем позицию курсора
                myTextBox1.CaretIndex = caretIndex + 2;
            }

            TextBox textBox = sender as TextBox;

            if (!string.IsNullOrEmpty(textBox.Text))
            {
                string[] words = textBox.Text.Split(' ');
                StringBuilder newText = new StringBuilder();

                foreach (string word in words)
                {
                    char[] chars = word.ToCharArray();
                    chars[0] = char.ToUpper(chars[0]);

                    newText.Append(new string(chars));
                    newText.Append(" ");
                }

                textBox.Text = newText.ToString().Trim();
                textBox.CaretIndex = textBox.Text.Length;
            }

        }

        private void TextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {
            button.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#B7968D"));
            button.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#D8D5D2"));

            TextBox textBox = sender as TextBox;

            if (!string.IsNullOrEmpty(textBox.Text))
            {
                string[] words = textBox.Text.Split(' ');
                StringBuilder newText = new StringBuilder();

                foreach (string word in words)
                {
                    char[] chars = word.ToCharArray();
                    chars[0] = char.ToUpper(chars[0]);

                    newText.Append(new string(chars));
                    newText.Append(" ");
                }

                textBox.Text = newText.ToString().Trim();
                textBox.CaretIndex = textBox.Text.Length;
            }
        }

        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
           
        }

        private void ListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string messageBoxText = "Вы записаны на занятие. Просьба приходить за 10-15 минут до начала занятия";
            string caption = "Школа танцев «MOVE»";
            MessageBoxButton button = MessageBoxButton.OKCancel;

            MessageBox.Show(messageBoxText, caption, button);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(null);
        }
    }
}
