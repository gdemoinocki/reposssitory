from copy import copy

from double_linked_list import DoublyLinkedList, StudentNode

if __name__ == "__main__":
    students = DoublyLinkedList()
    students.append(StudentNode("Ярик 1", 2000, 2021, [1, 1, 3, 4, 5]))
    students.append(StudentNode("Ярик 2", 2001, 2020, [5, 2, 3, 4, 5]))
    students.append(StudentNode("Ярик 3", 2002, 2021, [1, 3, 3, 2, 5]))
    students.append(StudentNode("Ярик 4", 2002, 2020, [1, 3, 3, 2, 5]))
    students.append(StudentNode("Ярик 5", 2002, 2021, [1, 3, 3, 2, 5]))
    students.append(StudentNode("Ярик 6", 2002, 2021, [1, 3, 3, 2, 5]))

    students_filtered = DoublyLinkedList()

    for student in students:
        if student.enrollment_year % 2:
            students_filtered.append(copy(student))
            students.remove(student)

    print(students)
    print(students_filtered)