﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Net.Mime.MediaTypeNames;

namespace UI
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private bool isComicSansMS = true;

        public MainWindow()
        {
            InitializeComponent();
        }
        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            tb1.FontSize = 36;
            bn1.FontSize = 18;
            bn2.FontSize = 18;
            bn3.FontSize = 18;
            bn4.FontSize = 18;
            bn5.FontSize = 18;
        }
        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            tb1.FontSize = 48;
            bn1.FontSize = 24;
            bn2.FontSize = 24;
            bn3.FontSize = 24;
            bn4.FontSize = 24;
            bn5.FontSize = 24;
        }
        private void Button_Click_7(object sender, RoutedEventArgs e)
        {
            tb1.FontSize = 50;
            bn1.FontSize = 32;
            bn2.FontSize = 32;
            bn3.FontSize = 28;
            bn4.FontSize = 32;
            bn5.FontSize = 32;
        }

        private void Button_Click1(object sender, RoutedEventArgs e)
        {
            Window1 window1 = new Window1();
            window1.Show();
            Hide();
            SoundPlayer Simple = new SoundPlayer(@"C:\Users\4769003\source\repos\UI\UI\knopka.wav");
            Simple.Play();
        }

        private void Button_Click3(object sender, RoutedEventArgs e)
        {
            Window2 window2 = new Window2();
            window2.Show();
            Hide();
            SoundPlayer Simple = new SoundPlayer(@"C:\Users\4769003\source\repos\UI\UI\knopka.wav");
            Simple.Play();
            double scale = ScaleSlider.Value;
            bn1.RenderTransform = new ScaleTransform(scale, scale);
        }

        private void Button_Click4(object sender, RoutedEventArgs e)
        {
            Window3 window3 = new Window3();
            window3.Show();
            Hide();
            SoundPlayer Simple = new SoundPlayer(@"C:\Users\4769003\source\repos\UI\UI\knopka.wav");
            Simple.Play();
        }

        private void Button_Click5(object sender, RoutedEventArgs e)
        {
            Window4 window4 = new Window4();
            window4.Show();
            Hide();
            SoundPlayer Simple = new SoundPlayer(@"C:\Users\4769003\source\repos\UI\UI\knopka.wav");
            Simple.Play();
        }
        private void Button_Click6(object sender, RoutedEventArgs e)
        {
            Window5 window5 = new Window5();
            window5.Show();
            Hide();
            SoundPlayer Simple = new SoundPlayer(@"C:\Users\4769003\source\repos\UI\UI\knopka.wav");
            Simple.Play();
        }

        private void Button_Click2(object sender, RoutedEventArgs e)
        {
            if (ButtonPanel.Visibility == Visibility.Collapsed)
                ButtonPanel.Visibility = Visibility.Visible;
            else
                ButtonPanel.Visibility = Visibility.Collapsed;
            SoundPlayer Simple = new SoundPlayer(@"C:\Users\4769003\source\repos\UI\UI\knopka.wav");
            Simple.Play();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (isComicSansMS)

            {
                tb1.FontFamily = new FontFamily("Comic Sans MS");
                bn1.FontFamily = new FontFamily("Comic Sans MS");
                bn2.FontFamily = new FontFamily("Comic Sans MS");
                bn3.FontFamily = new FontFamily("Comic Sans MS");
                bn4.FontFamily = new FontFamily("Comic Sans MS");
                bn5.FontFamily = new FontFamily("Comic Sans MS");
            }
            else
            {
                tb1.FontFamily = new FontFamily("Times New Roman");
                bn1.FontFamily = new FontFamily("Times New Roman");
                bn2.FontFamily = new FontFamily("Times New Roman");
                bn3.FontFamily = new FontFamily("Times New Roman");
                bn4.FontFamily = new FontFamily("Times New Roman");
                bn5.FontFamily = new FontFamily("Times New Roman");
            }
            isComicSansMS = !isComicSansMS;
            SoundPlayer Simple = new SoundPlayer(@"C:\Users\4769003\source\repos\UI\UI\knopka.wav");
            Simple.Play();
        }
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn1.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn2.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn3.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn4.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn5.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn6.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn7.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn11.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn12.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn13.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn14.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));

            bn1.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn2.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn3.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn4.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn5.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn6.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn7.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn11.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn12.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn13.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn14.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));

            bn1.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn2.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn3.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn4.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn5.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn6.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn7.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn11.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn12.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn13.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn14.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));

            tb1.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            
            SoundPlayer Simple = new SoundPlayer(@"C:\Users\4769003\source\repos\UI\UI\knopka.wav");
            Simple.Play();
        }
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn1.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn2.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn3.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn4.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn5.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn6.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn7.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn11.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn12.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn13.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            bn14.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));

            bn1.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn2.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn3.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn4.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn5.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn6.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn7.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn11.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn12.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn13.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn14.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));

            bn1.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn2.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn3.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn4.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn5.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn6.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn7.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn11.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn12.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn13.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            bn14.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));

            tb1.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));

            SoundPlayer Simple = new SoundPlayer(@"C:\Users\4769003\source\repos\UI\UI\knopka.wav");
            Simple.Play();
        }
        
        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            Hide();
            SoundPlayer Simple = new SoundPlayer(@"C:\Users\4769003\source\repos\UI\UI\knopka.wav");
            Simple.Play();
        }

        private void Button_Click_M(object sender, RoutedEventArgs e)
        {
            if (ScaleSlider.Visibility == Visibility.Collapsed)
                ScaleSlider.Visibility = Visibility.Visible;
            else
                ScaleSlider.Visibility = Visibility.Collapsed;
        }

        private void Button_Click_8(object sender, RoutedEventArgs e)
        {
            SoundPlayer Simple = new SoundPlayer(@"C:\Users\4769003\source\repos\UI\UI\knopka.wav");
            Simple.Play();

            if (im.Visibility == Visibility.Visible)
            {
                im.Visibility = Visibility.Hidden;
            }
            else
            {
                im.Visibility = Visibility.Visible;
            }
        }
    }
}
