﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace UI
{
    /// <summary>
    /// Логика взаимодействия для Window5.xaml
    /// </summary>
    public partial class Window5 : Window
    {
        public Window5()
        {
            InitializeComponent();
        }
        int n = 0;
        private void Button_Click1(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image files|*.bmp;*.jpg;*.png";
            ofd.FilterIndex = 1;
            if (ofd.ShowDialog() == true)
            {
                im1.Source = new BitmapImage(new Uri(ofd.FileName));
                lb1.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
                lb1.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
                n = 1;
            }
            SoundPlayer Simple = new SoundPlayer(@"C:\Users\4769003\source\repos\UI\UI\knopka.wav");
            Simple.Play();
        }
        private void Button_Click2(object sender, RoutedEventArgs e)
        {
            string gn = cb1.Text;
            string email = tb3.Text.Trim().ToLower();
            Regex regex = new Regex("^[а-яА-Я]*$");

            if (email.Length < 5 || !email.Contains("@") || !email.Contains("."))
            {
                tb3.ToolTip = "Это поле введено некорректно";
                tb3.BorderBrush = Brushes.Red;
                tb3.BorderThickness = new Thickness(2);
                tb5.Text = "";
            }
            //Проверка имени
            if (tb1.Text.Length < 1)
            {
                tb1.ToolTip = "Введите имя";
                tb1.BorderBrush = Brushes.Red;
                tb5.Text = "";
            }

            else if (!regex.IsMatch(tb1.Text))
            {
                tb1.ToolTip = "Это поле введено некорректно, введите только буквы";
                tb1.BorderBrush = Brushes.Red;
                tb5.Text = "";
            }

            else if(tb1.Text.Length > 1 & regex.IsMatch(tb1.Text))
            {
                if (!string.IsNullOrEmpty(tb1.Text))
                {
                    // Преобразуем первую букву в заглавную
                    tb1.Text = char.ToUpper(tb1.Text[0]) + tb1.Text.Substring(1);
                }
                tb1.ToolTip = " ";
                tb1.BorderBrush = Brushes.WhiteSmoke;
            }
            //Проверка фамилии
            if (tb2.Text.Length < 1)
            {
                tb2.ToolTip = "Введите фамилию:";
                tb2.BorderBrush = Brushes.Red;
                tb5.Text = "";
            }

            else if (!regex.IsMatch(tb2.Text))
            {
                tb2.ToolTip = "Это поле введено некорректно, введите только буквы";
                tb2.BorderBrush = Brushes.Red;
                tb5.Text = "";
            }

            else if (tb2.Text.Length > 1 & regex.IsMatch(tb2.Text))
            {
                if (!string.IsNullOrEmpty(tb2.Text))
                {
                    // Преобразуем первую букву в заглавную
                    tb2.Text = char.ToUpper(tb2.Text[0]) + tb2.Text.Substring(1);
                }
                tb2.ToolTip = " ";
                tb2.BorderBrush = Brushes.WhiteSmoke;
            }
            //Проверка номера группы
            if (cb1.SelectedItem == null)
            {

                tb4.ToolTip = "Выберите номер группы";
                tb4.BorderBrush = Brushes.Red;
                tb5.Text = "";
            }
            //Проверка почты
            if (email.Length < 5 || !email.Contains("@") || !email.Contains("."))
            {
                tb3.ToolTip = "Это поле введено некорректно";
                tb3.BorderBrush = Brushes.Red;
                tb5.Text = "";
            }

            else if (cb1.SelectedItem != null)
            {
                tb4.ToolTip = " ";
                tb3.ToolTip = " ";
                tb3.BorderBrush = Brushes.WhiteSmoke;
                if (n == 1) 
                {
                    tb5.Text = tb1.Text + " " + tb2.Text + ", ученик группы № " + cb1.Text + ", ваша заявка принята! На вашу почту" + " " + tb3.Text + " будет отправлено письмо с подробностями.";
                }
                else
                {
                    tb5.Text = tb1.Text + " " + tb2.Text + ", ученик группы № " + cb1.Text + ", ваша заявка принята! На вашу почту" + " " + tb3.Text + " будет отправлено письмо с подробностями. Не забудьте принести рисунок организатору до 25-го числа этого месяца, иначе ваша заявка будет аннулированна!";
                }
            }
            SoundPlayer Simple = new SoundPlayer(@"C:\Users\4769003\source\repos\UI\UI\knopka.wav");
            Simple.Play();
        }

        private void Button_Click3(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Hide();
            SoundPlayer Simple = new SoundPlayer(@"C:\Users\4769003\source\repos\UI\UI\knopka.wav");
            Simple.Play();
        }
    }
}
