﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace UI
{
    /// <summary>
    /// Логика взаимодействия для Window2.xaml
    /// </summary>
    /// 
    public partial class Window2 : Window
    {
        private bool isCorbel = true;
        public Window2()
        {
            InitializeComponent();
        }
        private void Button_Click2(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Hide();
            SoundPlayer Simple = new SoundPlayer(@"C:\Users\4769003\source\repos\UI\UI\knopka.wav");
            Simple.Play();
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (isCorbel)
            {
                FontFamily = new FontFamily("Comic Sans MS");
            }
            else
            {
                FontFamily = new FontFamily("Times New Roman");

            }
            isCorbel = !isCorbel;
            SoundPlayer Simple = new SoundPlayer(@"C:\Users\4769003\source\repos\UI\UI\knopka.wav");
            Simple.Play();

        }
        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            Window2 Window2 = new Window2();
            Window2.Show();
            Hide();
            SoundPlayer Simple = new SoundPlayer(@"C:\Users\4769003\source\repos\UI\UI\knopka.wav");
            Simple.Play();
        }
    }
}
