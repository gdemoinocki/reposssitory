from copy import copy
from double_linked_list import DoublyLinkedList, StudentNode

#Выводим список студентов на экран.
def display_students(students, list_name):
    print(f"\nСписок студентов {list_name}:")
    for student in students:
        print(student)

if __name__ == "__main__":
    students = DoublyLinkedList()
    students.append(StudentNode("Элина", 2006, 2024, [4, 4, 4, 4, 5]))
    students.append(StudentNode("Ирина", 2002, 2020, [5, 3, 4, 4, 5]))
    students.append(StudentNode("Виктор", 2000, 2023, [2, 5, 3, 4, 4]))
    students.append(StudentNode("Алексей", 2002, 2020, [4, 4, 4, 4, 5]))
    students.append(StudentNode("Александр", 2004, 2023, [5, 5, 3, 4, 4]))
    students.append(StudentNode("Юрий", 2005, 2024, [5, 5, 3, 5, 3]))

students_filtered = DoublyLinkedList()
# Разделяем студентов на два списка: четный и нечетный год поступления
for student in students:
    if student.enrollment_year % 2:
        students_filtered.append(copy(student))
        students.remove(student)
display_students(students, "с четным годом поступления")
display_students(students_filtered, "с нечетным годом поступления")