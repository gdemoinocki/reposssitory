class StudentNode:
    def __init__(self, surname, birth_year, enrollment_year, grades, _prev=None, _next=None):# Инициализация узла студента
        self.surname: str = surname  # Фамилия студента
        self.birth_year: int = birth_year  # Год рождения студента
        self.enrollment_year: int = enrollment_year  # Год поступления студента
        self.grades: list[int] = grades  # Оценки студента
        self.next: StudentNode | None = _next  # Ссылка на следующий узел в списке
        self.prev: StudentNode | None = _prev  # Ссылка на предыдущий узел в списке

    def __str__(self):# Возвращает строковое представление узла студента
        return f"{{ {self.surname} }} {{ {self.birth_year} }} {{ {self.enrollment_year} }} {{ {self.grades} }}"

    def __copy__(self):# Возвращает копию текущего узла студента
        return StudentNode(
            self.surname, self.birth_year, self.enrollment_year, self.grades
        )

    def __eq__(self, other):# Проверяет равенство текущего узла и другого узла
        if other is None:  # Если другой узел равен None, возвращаем False
            return False

        if not isinstance(other, StudentNode):  # Если другой объект не является StudentNode, вызываем ошибку
            raise TypeError(f" {type(other)} not StudentNode")

        return str(self) == str(other)  # Сравниваем строковые представления узлов

    def __ne__(self, other):# Проверяет неравенство текущего узла и другого узла
        return not self.__eq__(other)  # Возвращает отрицание результата __eq__

    def __lt__(self, other):# Проверяет, меньше ли текущий узел другого узла (по фамилии)
        if not isinstance(other, StudentNode):  # Если другой объект не является StudentNode, вызываем ошибку
            raise TypeError(f" {type(other)} not StudentNode")
        return self.surname < other.surname  # Сравниваем фамилии

    def __gt__(self, other):# Проверяет, больше ли текущий узел другого узла (по фамилии)
        if not isinstance(other, StudentNode):  # Если другой объект не является StudentNode, вызываем ошибку
            raise TypeError(f" {type(other)} not StudentNode")
        return self.surname > other.surname  # Сравниваем фамилии

    def __le__(self, other):# Проверяет, меньше или равен ли текущий узел другому узлу
        return self.__lt__(other) or self.__eq__(other)  # Возвращает True, если узел меньше или равен

    def __ge__(self, other):# Проверяет, больше или равен ли текущий узел другому узлу
        return self.__gt__(other) or self.__eq__(other)  # Возвращает True, если узел больше или равен


class DoublyLinkedList:
    def __init__(self):# Инициализация двусвязного списка
        self.tail: StudentNode | None = None  # Хвост списка (последний элемент)
        self.head: StudentNode | None = None  # Голова списка (первый элемент)

    def append(self, node: StudentNode):
        # Добавляет узел в конец списка
        if self.tail is None:  # Если список пуст
            node.prev = None  # У предыдущего элемента нет узла
            node.next = None  # У следующего элемента нет узла
            self.tail = node  # Хвост списка становится новым узлом
            self.head = node  # Голова списка становится новым узлом
        else:  # Если список не пуст
            node.prev = self.tail  # Устанавливаем связь с предыдущим хвостом
            node.next = None  # У следующего элемента нет узла
            self.tail.next = node  # Устанавливаем связь с новым узлом
            self.tail = node  # Новый узел становится хвостом списка

    def remove(self, value: StudentNode):
        # Удаляет узел из списка
        if value.prev:  # Если у узла есть предыдущий элемент
            value.prev.next = value.next  # Устанавливаем связь предыдущего элемента с следующим
        else:  # Если узел является головой списка
            self.head = value.next  # Голова списка становится следующим элементом

        if value.next:  # Если у узла есть следующий элемент
            value.next.prev = value.prev  # Устанавливаем связь следующего элемента с предыдущим
        else:  # Если узел является хвостом списка
            self.tail = value.prev  # Хвост списка становится предыдущим элементом

    def sort(self):
        # Сортирует список по фамилии студентов
        if not self.head or not self.head.next:  # Если список пуст или содержит один элемент
            return

        sorted_tail = self.head  # Начало отсортированной части списка
        unsorted = self.head.next  # Начало неотсортированной части списка

        while unsorted:  # Пока есть неотсортированные элементы
            current = unsorted  # Текущий элемент для вставки
            unsorted = unsorted.next  # Переход к следующему неотсортированному элементу

            if current < sorted_tail:  # Если текущий элемент меньше последнего отсортированного
                sorted_tail.next = unsorted  # Устанавливаем связь последнего отсортированного с неотсортированным

                if current < self.head:  # Если текущий элемент меньше головы списка
                    current.next = self.head  # Устанавливаем связь текущего элемента с головой
                    current.prev = None  # У текущего элемента нет предыдущего элемента
                    self.head.prev = current  # Устанавливаем связь головы с текущим элементом
                    self.head = current  # Текущий элемент становится головой списка
                else:  # Если текущий элемент нужно вставить в середину списка
                    pointer = self.head  # Указатель для поиска места вставки
                    while pointer.next < current:  # Ищем место для вставки
                        pointer = pointer.next
                    current.next = pointer.next  # Устанавливаем связь текущего элемента с следующим
                    current.prev = pointer  # Устанавливаем связь текущего элемента с предыдущим
                    pointer.next.prev = current  # Устанавливаем связь следующего элемента с текущим
                    pointer.next = current  # Устанавливаем связь предыдущего элемента с текущим
            else:  # Если текущий элемент больше последнего отсортированного
                sorted_tail = current  # Текущий элемент становится последним отсортированным

        self.tail = sorted_tail  # Обновляем хвост списка

    def linear_search_by_surname(self, surname) -> StudentNode | None: # Линейный поиск узла по фамилии
        for i in self:  # Проходим по всем элементам списка
            if i.surname == surname:  # Если фамилия совпадает
                return i  # Возвращаем найденный узел
        return None  # Если узел не найден, возвращаем None

    def binary_search_by_surname(self, surname) -> StudentNode | None:# Бинарный поиск узла по фамилии
        def get_middle(start, end):
            # Находит середину списка между start и end
            slow = start  # Медленный указатель
            fast = start.next  # Быстрый указатель

            while fast != end:  # Пока быстрый указатель не достиг конца
                fast = fast.next  # Перемещаем быстрый указатель на следующий элемент
                if fast != end:  # Если быстрый указатель не достиг конца
                    fast = fast.next  # Перемещаем быстрый указатель еще на один элемент
                    slow = slow.next  # Перемещаем медленный указатель на один элемент
            return slow  # Возвращаем середину списка

        left = self.head  # Левый указатель (начало списка)
        right = None  # Правый указатель (конец списка)

        while left != right:  # Пока левый указатель не совпал с правым
            mid = get_middle(left, right)  # Находим середину
            if mid.surname == surname:  # Если фамилия совпадает
                return mid  # Возвращаем найденный узел
            elif mid.surname < surname:  # Если фамилия в середине меньше искомой
                left = mid.next  # Сдвигаем левый указатель
            else:  # Если фамилия в середине больше искомой
                right = mid  # Сдвигаем правый указатель

        return None  # Если узел не найден, возвращаем None

    def __len__(self):# Возвращает количество узлов в списке
        count = 0  # Счетчик узлов
        for _ in self:  # Проходим по всем элементам списка
            count += 1  # Увеличиваем счетчик
        return count  # Возвращаем количество узлов

    def __iter__(self):
        # Итератор для обхода списка
        current = self.head  # Начинаем с головы списка
        while current is not None:  # Пока не достигнут конец списка
            yield current  # Возвращаем текущий узел
            current = current.next  # Переходим к следующему узлу

    def __str__(self):# Возвращает строковое представление списка
        return " <-> ".join([str(i) for i in self])  # Соединяем строковые представления узлов

