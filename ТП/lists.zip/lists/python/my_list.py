# Класс ListNode представляет узел связного списка
class ListNode:
    def __init__(self, *args):
        # Если аргументы отсутствуют, узел не инициализируется
        if not args:
            return

        # Если передан один аргумент, он становится значением узла, а next устанавливается в None
        if len(args) == 1:
            self.value = args[0]
            self.next = None
        # Если передано два аргумента и второй аргумент является экземпляром ListNode,
        # первый аргумент становится значением узла, а второй — следующим узлом
        elif len(args) == 2 and isinstance(args[1], ListNode):
            self.value = args[0]
            self.next = args[1]
        # В противном случае вызывается исключение TypeError
        else:
            raise TypeError()

    # Строковое представление узла
    def __str__(self):
        return f"({self.value}) -> {self.next}"

    # Сравнение на равенство узлов
    def __eq__(self, val):
        if not isinstance(val, ListNode):#проверяем является ли val экземляром
            return False

        return self.value == val.value and self.next == val.next

    # Сравнение на неравенство узлов
    def __ne__(self, val):
        return not self.__eq__(val)

# Класс MyList представляет связный список, построенный на узлах ListNode
class MyList:
    def __init__(self, *args):
        # Если передан аргумент, создается головной узел с этим значением, и _count(счетчик элементов) устанавливается в 1
        if args and args[0] is not None:
            x = ListNode(args[0])
            self.head = x
            self._count = 1
        # В противном случае, головной узел устанавливается в None, и _count устанавливается в 0 (пустой список)
        else:
            self.head = None
            self._count = 0

    # Добавление элемента в конец списка
    def append(self, value):
        # Если список не пустой, перебирает узлы до конца и добавляет новый узел с переданным значением
        if self.head:
            a = self.head
            while a.next:
                a = a.next
            a.next = ListNode(value)
        # Если список пустой, создает новый головной узел с переданным значением
        else:
            self.head = ListNode(value)
        # Увеличивает счетчик элементов _count на 1
        self._count += 1

    # Возвращает количество элементов в списке
    def __len__(self):
        return self._count

    # Строковое представление списка
    def __str__(self):
        # Если список пустой, возвращает "None"
        if not len(self):
            return "None"
        else:
            a = self.head
            result = f"({a.value}) -> "
            # Перебирает узлы и формирует строку в формате (значение) -> (значение) -> ... -> None
            while a.next:
                a = a.next
                result += f"({a.value}) -> "
            a = a.next
            result += f"{a}"
            return result

    # Строковое представление списка для отладки
    def __repr__(self):
        return str(self)

    # Сравнение на равенство списков
    def __eq__(self, n2):
        if isinstance(n2, MyList):# если n2 является экземпляром MyList
            return str(self) == str(n2) #сравниваем строковые представления
        else:
            return False

    # Сравнение на неравенство списков
    def __ne__(self, n2):
        return not self == n2

    # Проверка наличия элемента в списке
    def __contains__(self, value):
        # Если список пустой, возвращает False
        if not len(self):
            return False
        else:
            a = self.head
            # Если головной узел содержит переданное значение, возвращает True
            if a.value == value:
                return True
            # Перебирает узлы и сравнивает их значения с переданным значением
            while a.next:
                a = a.next
                if a.value == value:
                    return True
        return False

    # Удаление первого совпавшего элемента из списка
    def remove(self, value):
        # Если список пустой, вызывает исключение ValueError
        if self.head is None:
            raise ValueError()

        # Если головной узел содержит переданное значение, удаляет головной узел и уменьшает счетчик _count на 1
        if self.head.value == value:
            self.head = self.head.next
            self._count -= 1
            return

        current = self.head
        # Перебирает узлы и удаляет первый узел, содержащий переданное значение
        while current.next:
            if current.next.value == value:
                current.next = current.next.next
                self._count -= 1
                return
            current = current.next

        # Если такой узел не найден, вызывает исключение ValueError
        raise ValueError()

    # Удаление и возвращение последнего элемента из списка
    def pop(self):
        # Если список пустой, вызывает исключение IndexError
        if self.head is None:
            raise IndexError('pop from empty list')

        current = self.head
        # Если в списке один элемент, удаляет головной узел и уменьшает счетчик _count на 1
        if current.next is None:
            value = current.value
            self.head = None
            self._count -= 1
            return value

        # Перебирает узлы до предпоследнего и удаляет последний узел, уменьшая счетчик _count на 1
        while current.next.next:
            current = current.next
        value = current.next.value
        current.next = None
        self._count -= 1
        return value

    # Очистка списка
    def clear(self):
        self.head = None
        self._count = 0

    # Расширение текущего списка элементами другого
    def extend(self, other):
        # Если переданный объект является экземпляром MyList, добавляет все его элементы в текущий список
        if isinstance(other, MyList):
            a = other.head

            while a:
                self.append(a.value)
                a = a.next

        # В противном случае, вызывает исключение TypeError
        else:
            raise TypeError()

    # Копирование списка
    def copy(self):
        new_list = MyList()
        current = self.head
        # Создает новый список и копирует в него все элементы текущего списка
        while current:
            new_list.append(current.value)
            current = current.next
        return new_list

    # Вставка элемента в список по указанному индексу
    def insert(self, index, value):
        # Если индекс не является целым числом или отрицательным, вызывает исключение IndexError
        if (not isinstance(index, int)) or index < 0:
            raise IndexError()
        # Если индекс больше или равен количеству элементов в списке, добавляет элемент в конец списка
        if index >= self._count:
            self.append(value)
            return
        # Если индекс равен 0, вставляет новый узел в начало списка
        if index == 0:
            new_node = ListNode(value, self.head)
            self.head = new_node
            self._count += 1
            return
        current = self.head
        # Перебирает узлы до узла с индексом index - 1 и вставляет новый узел после него
        for _ in range(index - 1):
            current = current.next
            if current is None:
                return
        new_node = ListNode(value, current.next)
        current.next = new_node
        self._count += 1

    # Поиск индекса элемента в списке
    def index(self, value):
        current = self.head
        idx = 0
        # Перебирает узлы и возвращает индекс первого узла, содержащего переданное значение
        while current:
            if current.value == value:
                return idx
            current = current.next
            idx += 1
        # Если такой узел не найден, вызывает исключение ValueError
        raise ValueError(f"{value} is not in list")

    # Подсчет элементов в списке
    def count(self, value):
        _count = 0
        current = self.head
        # Перебирает узлы и подсчитывает количество узлов, содержащих переданное значение
        while current:
            if current.value == value:
                _count += 1
            current = current.next
        return _count

    # Разворот списка
    def reverse(self):
        prev = None
        current = self.head
        # Разворачивает список, изменяя ссылки next узлов
        while current:
            next_node = current.next
            current.next = prev
            prev = current
            current = next_node
        self.head = prev
