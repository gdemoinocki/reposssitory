#ifndef BST_H
#define BST_H
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <sys/stat.h>

// Определение структуры узла дерева.
typedef struct tree_node_t
{
    void *data;              // Указатель на данные, хранящиеся в узле.
    struct tree_node_t *left; // Указатель на левый дочерний узел.
    struct tree_node_t *right; // Указатель на правый дочерний узел.
} tree_node_t;

//определение структуры бинарного дерева поиска (BST)
typedef struct
{
    tree_node_t *root;       //указатель на корневой узел дерева
    size_t data_size;        //размер данных, хранящихся в каждом узле
} bst_t;

typedef int (*comparator_func)(const void *, const void *);//тип функции-компаратора, используемой для сравнения данных в BST

bst_t *bst_create(size_t);//создание нового BST
bool bst_empty(bst_t *);//проверка, пусто ли BST
bool bst_contains(bst_t *, void *, comparator_func);//проверка, содержит ли BST определённый элемент данных
size_t bst_length(bst_t *);//получение количества узлов в BST
void bst_insert_node(bst_t *, void *, comparator_func);//вставка нового узла в BST
void bst_delete_node(bst_t *, void *, comparator_func);//удаление узла из BST
void bst_insert_array(bst_t *, size_t, void *, comparator_func);//вставка массива данных в BST
void bst_destroy(bst_t *);//уничтожение BST и освобождения его памяти
void bst_print_int(bst_t *, FILE *);//печать BST в целочисленном формате
void *bst_preorder_traversal(bst_t *);//префиксный обход BST
void *bst_inorder_traversal(bst_t *);//инфиксный обход BST
void *bst_postorder_traversal(bst_t *);//постфиксный обход BST
void *bst_level_order_traversal(bst_t *);//обход BST по уровням
#endif