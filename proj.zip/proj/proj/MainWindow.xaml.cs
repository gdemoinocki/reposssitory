﻿using System.Data;
using System.Windows;
using System.Windows.Controls;
using Npgsql;

namespace proj
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>

    public partial class MainWindow : Window
    {
        private const string connectionString = "Server=localhost;Port=5432;Database=fridge;User Id=postgres;Password=1234";
        public MainWindow()
        {
            InitializeComponent();

            string sql = "SELECT * FROM products";

            // Создаем подключение к базе данных
            using (var connection = new NpgsqlConnection(connectionString))
            {
                connection.Open(); // Открываем соединение

                // Создаем команду, используя строку запроса и подключение
                using (var cmd = new NpgsqlCommand(sql, connection))
                {
                    // Создаем адаптер данных
                    var adapter = new NpgsqlDataAdapter(cmd);

                    // Создаем DataSet для хранения результирующих данных
                    var dataSet = new System.Data.DataSet();

                    // Выводим данные в DataGrid
                    adapter.Fill(dataSet);
                    dg.ItemsSource = dataSet.Tables[0].DefaultView;
                    // Сортируем данные по первичному ключу
                    dataSet.Tables[0].DefaultView.Sort = "Код_продукта";

                }
            }

        }

        private void Button_Click1(object sender, RoutedEventArgs e)
        {
            Window2 b = new Window2();
            b.Show();
            this.Close();
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }
        
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            void RefreshDataGrid()
            {
                // Создать соединение с базой данных
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();

                    // Создать команду SQL для извлечения данных
                    var command = new NpgsqlCommand("SELECT * FROM products", connection);

                    // Создать адаптер данных
                    var adapter = new NpgsqlDataAdapter(command);

                    // Заполнить набор данных
                    var dataSet = new DataSet();
                    adapter.Fill(dataSet);

                    // Привязать набор данных к DataGrid
                    dg.DataContext = dataSet;
                }
            }
            var selectedRow = dg.SelectedItem as DataRowView;

            // Извлечь значение первичного ключа
            var primaryKeyValue = selectedRow["Код_продукта"];

            // Создать соединение с базой данных
            using (var connection = new NpgsqlConnection(connectionString))
            {
                connection.Open();

                // Создать команду SQL для удаления записи
                var command = new NpgsqlCommand("DELETE FROM products WHERE Код_продукта = @primary_key", connection);
                command.Parameters.AddWithValue("@primary_key", primaryKeyValue);

                // Выполнить команду
                command.ExecuteNonQuery();

                var command2 = new NpgsqlCommand("SELECT * FROM products", connection);
                connection.Close();

            }

            RefreshDataGrid();
        }
        public void AddRecordToDatabase(DataRow row)
        {
            NpgsqlConnection conn = new NpgsqlConnection(connectionString);
            string sql = "INSERT INTO products (Наименование, Количество, Срок_годности, Категория) VALUES (@val1, @val2, @val3, @val4)";
            NpgsqlCommand cmd = new NpgsqlCommand(sql, conn);

            cmd.Parameters.AddWithValue("val1", row["Наименование"]);
            cmd.Parameters.AddWithValue("val2", row["Количество"]);
            cmd.Parameters.AddWithValue("val3", row["Срок_годности"]);
            cmd.Parameters.AddWithValue("val4", row["Категория"]);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            DataRowView selectedRow = (DataRowView)dg.SelectedItem;
            DataRow row = selectedRow.Row;

            AddRecordToDatabase(row);

        }
    }
}
   
