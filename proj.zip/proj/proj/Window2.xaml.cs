﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using Npgsql;

namespace proj
{
    /// <summary>
    /// Логика взаимодействия для Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        private const string connectionString = "Server=localhost;Port=5432;Database=fridge;User Id=postgres;Password=1234";
        public Window2()
        {
            InitializeComponent();
            // Создаем подключение к базе данных
            using (var connection = new NpgsqlConnection(connectionString))
            {
                connection.Open(); // Открываем соединение

                var command = new NpgsqlCommand("SELECT * FROM products WHERE Срок_годности <@expiration_date", connection);
                command.Parameters.AddWithValue("@expiration_date", DateTime.Now.AddDays(3));
                var adapter = new NpgsqlDataAdapter(command);

                // Заполнить набор данных
                var dataSet = new DataSet();
                adapter.Fill(dataSet);

                // Привязать набор данных к DataGrid
                dg2.ItemsSource = dataSet.Tables[0].DefaultView;

                var command2 = new NpgsqlCommand("SELECT * FROM products WHERE Количество < 2", connection);
                //command2.Parameters.AddWithValue("@expiration_date", DateTime.Now.AddDays(3));
                var adapter2 = new NpgsqlDataAdapter(command2);

                // Заполнить набор данных
                var dataSet2 = new DataSet();
                adapter2.Fill(dataSet2);

                // Привязать набор данных к DataGrid
                dg1.ItemsSource = dataSet2.Tables[0].DefaultView;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow a = new MainWindow();
            a.Show();
            this.Close();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
